import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import '@fontsource/roboto'; // Defaults to weight 400.

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
    <App />
);

